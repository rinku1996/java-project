function validateform(){  
var callno=document.myform.callno.value;  
var name=document.myform.name.value;  
var author=document.myform.author.value;
var publisher=document.myform.publisher.value;
var quantity=document.myform.quantity.value;
  
if (callno==null || callno==""){  
  alert("Call No can't be blank");  
  return false;  
}
else if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
else if (author==null || author==""){  
  alert("Author Name can't be blank");  
  return false;  
}
else if (publisher==null || publisher==""){  
  alert("Publisher can't be blank");  
  return false;  
}
else if (quantity==null || quantity==""){  
  alert("Quantity can't be blank");  
  return false;  
}



}  