function validateform(){  
var callno=document.myform.callno.value;  
var studentid=document.myform.studentid.value;  

  
if (callno==null || callno==""){  
  alert("Call No can't be blank");  
  return false;  
}
else if (studentid==null || studentid==""){  
  alert("Student ID can't be blank");  
  return false;  
}

}  