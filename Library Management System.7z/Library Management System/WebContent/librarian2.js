function validateform(){  
var callno=document.myform.callno.value;  
var studentid=document.myform.studentid.value;  
var studentname=document.myform.studentname.value;

  
if (callno==null || callno==""){  
  alert("Call No can't be blank");  
  return false;  
}

else if (studentid==null || studentid==""){  
  alert("studentid can't be blank");  
  return false;  
}
else if (studentname==null || studentname==""){  
  alert("studentname can't be blank");  
  return false;  
}
   
var x=document.myform.studentemail.value;  
var atposition=x.indexOf("@");  
var dotposition=x.lastIndexOf(".");  
if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  alert("Please enter a valid e-mail address");  
  return false;  
  }  


}  