package com.sai.servlets;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sai.beans.BookBean;
import com.sai.beans.IssueBookBean;
import com.sai.dao.BookDao;
import com.sai.dao.LibrarianDao;
@WebServlet("/IssueBook")
public class IssueBook extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Add Book Form</title>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("navlibrarian.html").include(request, response);
		
		
		String callno=request.getParameter("callno");
		String studentid=request.getParameter("studentid");
		String studentname=request.getParameter("studentname");
		String studentemail=request.getParameter("studentemail");
		
		IssueBookBean bean=new IssueBookBean(callno,studentid,studentname,studentemail);
		
		if(BookDao.authenticateStudentid(studentid)){
			HttpSession session=request.getSession();
			session.setAttribute("studentid",studentid);
			out.print("<br><br><br><br><br><center><h1>Student ID already exists</h1></center></body></html>");
			
		}
		else if(BookDao.authenticateStudentEmail(studentemail)){
			HttpSession session=request.getSession();
	
			session.setAttribute("studentemail", studentemail);
			out.print("<br><br><br><br><br><center><h1>Email already exists</h1></center></body></html>");
	
			
		}
		int i=BookDao.issueBook(bean);
		if(i>0){
			out.println("<br><br><br><br><br><center><h3>Book issued successfully</center></h3>");
		}else {
			out.println("<br><br><br><br><br><br><center><h3>Sorry, unable to issue book.</h3><p>We may have sortage of books. Kindly visit later.</p></center>");
		}
		out.close();
		
		
		
	}

}
