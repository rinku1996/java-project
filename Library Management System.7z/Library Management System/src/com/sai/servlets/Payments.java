package com.sai.servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sai.beans.BookBean;
import com.sai.beans.IssueBookBean;
import com.sai.dao.BookDao;
@WebServlet("/Payments")
public class Payments extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>View Issued Book</title>");
		out.println("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 70%;}td, th {");
		out.println("border: 2px solid black;text-align: left;padding: 5px;}tr:nth-child(even) {");
		out.println("background-color: yellow;}</style>");
		out.println("</head>");
		
		out.println("<body>");
		request.getRequestDispatcher("navlibrarian.html").include(request, response);
		
		
		List<IssueBookBean> list=BookDao.viewIssuedBooks();
		
		out.println("<br><br><br><br><br><br><table>");
		out.println("<tr><th>Student Id</th><th>Issued Date</th><th>Last Date</th><th>Return Status</th><th>Please Send Message</th></tr>");
		for(IssueBookBean bean:list){
			out.println("<tr><td>"+bean.getStudentid()+"</td><td>"+bean.getIssueddate()+"</td><td>"+bean.getIssueddate()+"</td><td>"+bean.getReturnstatus()+"</td>"
					+ "<td><form action='mailto:someone@example.com' method='post' enctype='text/plain'>\r\n" + 
					"Name:<input type='text' name='name' value="+bean.getStudentname()+"><br>\r\n" + 
					"E-mail:\n" + 
					"<input type=\"text\" name='mail' value="+bean.getStudentemail()+"><br>\r\n" + 
					"Comment:<br>\r\n" + 
					"<input type='text' name='comment' value='Hi,"+bean.getStudentname()+" Your Id No:"+bean.getStudentid()+" over due your book.Fine. Rs.20/-' size=\"50\"><br><br>\r\n" + 
					"<input type='submit' value='Send'>\r\n" +  
					"</form></td></tr>");
		}
		out.println("</table>");
		
		
		
		
		out.close();
	}
}
