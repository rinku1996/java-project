package com.sai.servlets;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sai.beans.LibrarianBean;
import com.sai.dao.LibrarianDao;
@WebServlet("/AddLibrarian")
public class AddLibrarian extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Add Librarian</title>");
		out.println("</head>");
		out.println("<body>");
		
		
		request.getRequestDispatcher("navadmin.html").include(request, response);
		
		//out.print("<br><br><br><br><center><h4>Librarian added un successfully</h4></center>");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String smobile=request.getParameter("mobile");
		long mobile=Long.parseLong(smobile);
		if(LibrarianDao.authenticateEmail(email)){
			HttpSession session=request.getSession();
			session.setAttribute("email",email);
			out.print("<br><br><br><br><br><center><h1>E-mail already exists</h1></center></body></html>");
			
		}
		else if(LibrarianDao.authenticateMobile(mobile)){
			HttpSession session=request.getSession();
	
			session.setAttribute("mobile", mobile);
			out.print("<br><br><br><br><br><center><h1>Mobile No already exists</h1></center></body></html>");
	
			
		}
		
		else{
			LibrarianBean bean=new LibrarianBean(name, email, password, mobile);
			
			LibrarianDao.save(bean);
			out.print("<br><br><br><br><br><center><h1>Librarian added successfully</h1></center></body></html>");
			//request.getRequestDispatcher("addlibrarianform.html").include(request, response);
		}
		
		
		
		

		out.close();
	}

}
