package com.sai.servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sai.beans.LibrarianBean;
import com.sai.dao.LibrarianDao;
@WebServlet("/EditLibrarianForm")
public class EditLibrarianForm extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Edit Librarian Form</title>");

		out.println("<link rel='stylesheet' href='pages.css'/>");
		out.println("</head>");
		out.println("<body>");
		
		//request.getRequestDispatcher("navadmin.html").include(request, response);
		
	
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		LibrarianBean bean=LibrarianDao.viewById(id);
		
		out.print("<center><div class='h1'><b> Edit Librarian </b><br><br><br><form action='EditLibrarian' method='post' autocomplete='on' style='width:300px;'>");
		out.print("<input type='hidden' name='id' value='"+bean.getId()+"'/>");
		out.print("<table><tr><td><font size='4' color='black'>Name </td><td><input name='name' value='"+bean.getName()+"' id='name1'style='wdth:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>E-mail </td><td><input name='email' value='"+bean.getEmail()+"' id='email1' autocomplete='off' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Password </td><td><input type='password' name='password' value='"+bean.getPassword()+"' id='password1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Mobile Number </td><td><input name='mobile' value='"+bean.getMobile()+"' id='mobile1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr></table><br><br><button type='submit' style='width:200px;height:30px;'>Update</button>");
		out.print("</form></div></center>");
		
		
		
		out.close();
		
	}
}
